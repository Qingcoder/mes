"""Pydantic 请求/响应模型"""
from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel


class LoginIn(BaseModel):
    username: str
    password: str


class LoginOut(BaseModel):
    ok: bool
    token: Optional[str] = None
    name: Optional[str] = None
    role: Optional[str] = None
    msg: Optional[str] = None


class WOIn(BaseModel):
    wo_no: str
    product: str
    batch: Optional[str] = None
    plan_qty: int = 0
    location: Optional[str] = "戴盟公司"
    stations: List[str] = []
    pack_qty: int = 1
    rev: Optional[int] = None   # 更新时带版本号


class SNImportIn(BaseModel):
    wo_id: int
    sns: List[str]


class StationIn(BaseModel):
    sn: str
    station: str
    result: str          # pass / fail
    fail_code: Optional[str] = None
    operator: Optional[str] = None
    rev: Optional[int] = None


class PackIn(BaseModel):
    box_no: str
    sns: List[str]
    operator: Optional[str] = None


class WOLine(BaseModel):
    id: int
    wo_no: str
    product: str
    batch: Optional[str] = None
    plan_qty: int
    location: Optional[str] = None
    stations: List[str] = []
    pack_qty: int = 1
    status: str
    rev: int

    class Config:
        from_attributes = True


class UnitLine(BaseModel):
    id: int
    sn: str
    wo_no: Optional[str] = None
    current_station: Optional[str] = None
    state: str
    fail_code: Optional[str] = None
    box_no: Optional[str] = None

    class Config:
        from_attributes = True


class RecordLine(BaseModel):
    id: int
    sn: Optional[str] = None
    station: str
    result: str
    fail_code: Optional[str] = None
    operator: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class BoxLine(BaseModel):
    id: int
    box_no: str
    wo_no: Optional[str] = None
    qty: int
    status: str
    closed_at: Optional[datetime] = None

    class Config:
        from_attributes = True
