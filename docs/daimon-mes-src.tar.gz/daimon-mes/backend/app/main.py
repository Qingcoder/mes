"""戴盟 MES 生产管理平台 · 后端 API
启动：uvicorn app.main:app --reload --port 8007
接口文档：http://127.0.0.1:8007/docs
"""
import os
from datetime import datetime
from typing import List

from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, Session

from . import models
from .schemas import (
    LoginIn, LoginOut, WOIn, SNImportIn, StationIn, PackIn,
    WOLine, UnitLine, RecordLine, BoxLine,
)

# ---- 数据库：SQLite 起步，改这一个 URL 即可迁 PostgreSQL ----
DB_URL = os.getenv("MES_DB_URL", "sqlite:///./mes.db")
engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if "sqlite" in DB_URL else {})
if "sqlite" in DB_URL:
    @event.listens_for(engine, "connect")
    def _fk_on(dbapi_conn, conn_record):
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()
SessionLocal = sessionmaker(bind=engine, autoflush=False)
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="戴盟 MES 生产管理平台 API", version="V1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def seed(db: Session):
    if db.query(models.Account).count() == 0:
        db.add(models.Account(username="admin", password="123456", name="系统管理员", role="admin"))
    if db.query(models.Product).count() == 0:
        for code, name in [
            ("BACKPACK", "V2.9 无本体数采背包"),
            ("GRIPPER", "V2.9 无本体数采夹爪"),
            ("TELEOP", "三代遥操-背包版本"),
            ("BRACKET", "三代遥操-支架板"),
        ]:
            db.add(models.Product(code=code, name=name))
    db.commit()


@app.on_event("startup")
def on_startup():
    seed(SessionLocal())


def require_auth(authorization: str = Header(default="")):
    # V1 单账号：前端存 token="demo-token"，仅防误操作
    if authorization.replace("Bearer ", "").strip() != "demo-token":
        raise HTTPException(status_code=401, detail="未登录或登录已过期")


# ---- 登录 ----
@app.post("/api/login", response_model=LoginOut)
def login(body: LoginIn, db: Session = Depends(get_db)):
    a = db.query(models.Account).filter_by(username=body.username).first()
    if not a or a.password != body.password:
        return LoginOut(ok=False, msg="账号或密码错误")
    return LoginOut(ok=True, token="demo-token", name=a.name, role=a.role)


# ---- 产品（建单下拉）----
@app.get("/api/products")
def products(db: Session = Depends(get_db), _=Depends(require_auth)):
    return [{"code": p.code, "name": p.name} for p in db.query(models.Product).all()]


# ---- 工单 ----
@app.post("/api/wos", response_model=WOLine, dependencies=[Depends(require_auth)])
def create_wo(body: WOIn, db: Session = Depends(get_db)):
    if db.query(models.WorkOrder).filter_by(wo_no=body.wo_no).first():
        raise HTTPException(400, "工单号已存在")
    wo = models.WorkOrder(
        wo_no=body.wo_no, product=body.product, batch=body.batch,
        plan_qty=body.plan_qty, location=body.location or "戴盟公司",
        stations=body.stations, pack_qty=body.pack_qty or 1,
        status="released", rev=0,
    )
    db.add(wo); db.commit(); db.refresh(wo)
    return wo


@app.get("/api/wos", response_model=List[WOLine], dependencies=[Depends(require_auth)])
def list_wos(db: Session = Depends(get_db)):
    return db.query(models.WorkOrder).order_by(models.WorkOrder.id.desc()).all()


@app.get("/api/wos/{wo_id}", dependencies=[Depends(require_auth)])
def get_wo(wo_id: int, db: Session = Depends(get_db)):
    wo = db.query(models.WorkOrder).get(wo_id)
    if not wo:
        raise HTTPException(404, "工单不存在")
    return {
        "wo": WOLine.from_orm(wo),
        "sns": [UnitLine.from_orm(u) for u in wo.sns],
    }


# ---- SN 导入 ----
@app.post("/api/wos/{wo_id}/sns", dependencies=[Depends(require_auth)])
def import_sns(wo_id: int, body: SNImportIn, db: Session = Depends(get_db)):
    wo = db.query(models.WorkOrder).get(wo_id)
    if not wo:
        raise HTTPException(404, "工单不存在")
    added, skipped = 0, []
    for sn in [s.strip() for s in body.sns if s.strip()]:
        if db.query(models.Unit).filter_by(sn=sn).first():
            skipped.append(sn)   # 幂等：重复 SN 跳过
            continue
        db.add(models.Unit(sn=sn, wo_id=wo_id, state="pending"))
        added += 1
    db.commit()
    return {"added": added, "skipped": skipped}


# ---- 过站（核心：状态机收敛在服务层）----
@app.post("/api/station", dependencies=[Depends(require_auth)])
def station(body: StationIn, db: Session = Depends(get_db)):
    u = db.query(models.Unit).filter_by(sn=body.sn).first()
    if not u:
        raise HTTPException(404, "SN 不存在")
    wo = db.query(models.WorkOrder).get(u.wo_id)
    stations = wo.stations or []

    # 校验 1：站点必须在本单序列里
    if body.station not in stations:
        raise HTTPException(400, f"站点 {body.station} 不在本工单序列中")
    # 校验 2：不能跳站——最后一站必须是当前站或之前已过
    idx = stations.index(body.station)
    done = {r.station for r in u.records if r.result == "pass"}
    for s in stations[:idx]:
        if s not in done:
            raise HTTPException(400, f"不能跳站：请先完成 {s}")
    # 校验 3：重复提交幂等——本站已通过就不再记
    if body.station in done:
        return {"ok": True, "msg": "本站已通过（幂等跳过）", "state": u.state}

    result = body.result
    u.current_station = body.station
    if result == "pass":
        u.state = "station_done" if idx == len(stations) - 1 else "passed"
        u.fail_code = None
    elif result == "fail":
        u.state = "failed"
        u.fail_code = body.fail_code
    else:
        raise HTTPException(400, "result 只能是 pass 或 fail")

    db.add(models.StationRecord(
        unit_id=u.id, station=body.station, result=result,
        fail_code=body.fail_code, operator=body.operator,
        source_type="station",
    ))
    db.commit()
    return {"ok": True, "state": u.state, "msg": "过站成功"}


# ---- 返修回当前站 ----
@app.post("/api/wos/{wo_id}/sns/{sn}/rework", dependencies=[Depends(require_auth)])
def rework(wo_id: int, sn: str, db: Session = Depends(get_db)):
    u = db.query(models.Unit).filter_by(sn=sn, wo_id=wo_id).first()
    if not u:
        raise HTTPException(404, "SN 不存在")
    u.state = "rework"
    u.fail_code = None
    db.add(models.StationRecord(
        unit_id=u.id, station=u.current_station or "", result="rework",
        operator="system", source_type="station",
    ))
    db.commit()
    return {"ok": True, "state": u.state, "msg": "已回到当前站重测"}


# ---- 包装出库 ----
@app.post("/api/pack", dependencies=[Depends(require_auth)])
def pack(body: PackIn, db: Session = Depends(get_db)):
    units = db.query(models.Unit).filter(models.Unit.sn.in_(body.sns)).all()
    if len(units) != len(set(body.sns)):
        raise HTTPException(400, "有 SN 不存在")
    wo_ids = {u.wo_id for u in units}
    if len(wo_ids) != 1:
        raise HTTPException(400, "一箱只能装同一工单的 SN")
    wo = db.query(models.WorkOrder).next(iter(wo_ids)) if False else db.query(models.WorkOrder).get(next(iter(wo_ids)))

    for u in units:
        if u.state != "station_done":
            raise HTTPException(400, f"SN {u.sn} 未通过全部站点，不能装箱")

    box = models.Box(box_no=body.box_no, wo_id=wo.id, qty=len(units), status="closed", closed_at=datetime.utcnow())
    db.add(box); db.flush()
    for u in units:
        u.state = "packed"; u.box_no = body.box_no
    if db.query(models.Box).filter_by(wo_id=wo.id, status="closed").count() * wo.pack_qty >= wo.plan_qty:
        wo.status = "finished"
    db.commit()
    return {"ok": True, "box_no": body.box_no, "qty": len(units)}


# ---- 查询 ----
@app.get("/api/query/sn/{sn}", dependencies=[Depends(require_auth)])
def query_sn(sn: str, db: Session = Depends(get_db)):
    u = db.query(models.Unit).filter_by(sn=sn).first()
    if not u:
        raise HTTPException(404, "SN 不存在")
    wo = db.query(models.WorkOrder).get(u.wo_id)
    return {
        "unit": UnitLine.from_orm(u),
        "wo_no": wo.wo_no if wo else None,
        "records": [RecordLine.from_orm(r) for r in u.records],
    }


@app.get("/api/query/wo/{wo_id}", dependencies=[Depends(require_auth)])
def query_wo(wo_id: int, db: Session = Depends(get_db)):
    wo = db.query(models.WorkOrder).get(wo_id)
    if not wo:
        raise HTTPException(404, "工单不存在")
    units = wo.sns
    return {
        "wo": WOLine.from_orm(wo),
        "total": len(units),
        "station_done": sum(1 for u in units if u.state in ("station_done", "packed")),
        "failed": sum(1 for u in units if u.state == "failed"),
        "packed": sum(1 for u in units if u.state == "packed"),
    }


@app.get("/api/query/box/{box_no}", dependencies=[Depends(require_auth)])
def query_box(box_no: str, db: Session = Depends(get_db)):
    box = db.query(models.Box).filter_by(box_no=box_no).first()
    if not box:
        raise HTTPException(404, "箱号不存在")
    wo = db.query(models.WorkOrder).get(box.wo_id)
    return {
        "box": BoxLine.from_orm(box),
        "wo_no": wo.wo_no if wo else None,
        "sns": [u.sn for u in db.query(models.Unit).filter_by(box_no=box_no).all()],
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "platform": "戴盟 MES 生产管理平台"}


# ---- 静态前端：构建产物同端口托管，手机访问 http://<局域网IP>:8007 即可 ----
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

_DIST = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "dist"))
if os.path.isdir(_DIST):
    _assets = os.path.join(_DIST, "assets")
    if os.path.isdir(_assets):
        app.mount("/assets", StaticFiles(directory=_assets), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        if full_path.startswith("api/"):
            raise HTTPException(404, "接口不存在")
        target = os.path.abspath(os.path.join(_DIST, full_path))
        if full_path and target.startswith(_DIST) and os.path.isfile(target):
            return FileResponse(target)
        return FileResponse(os.path.join(_DIST, "index.html"))
