"""数据模型 · 戴盟 MES 生产管理平台
用 SQLAlchemy ORM 抽象，SQLite 起步、将来迁 PostgreSQL 只需改连接串。
SN 状态流转收敛在 service 层，页面只调 API。
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime, JSON,
    ForeignKey, UniqueConstraint,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    password = Column(String(128), nullable=False)  # V1 演示用明文，V1.1 改哈希
    name = Column(String(64))
    role = Column(String(32), default="operator")


class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(64), unique=True, nullable=False)
    name = Column(String(128), nullable=False)


class WorkOrder(Base):
    __tablename__ = "wos"
    id = Column(Integer, primary_key=True, index=True)
    wo_no = Column(String(64), unique=True, nullable=False, index=True)
    product = Column(String(128), nullable=False)
    batch = Column(String(64))
    plan_qty = Column(Integer, default=0)
    location = Column(String(64), default="戴盟公司")
    stations = Column(JSON, default=list)     # 每工单可配的站点序列 ["压力测试",...]
    pack_qty = Column(Integer, default=1)     # 自定义配比 N 台/箱
    status = Column(String(32), default="draft")  # draft/released/running/finished/closed
    rev = Column(Integer, default=0, nullable=False)  # 乐观锁版本号
    created_at = Column(DateTime, default=datetime.utcnow)

    sns = relationship("Unit", back_populates="wo", cascade="all, delete-orphan")


class Unit(Base):
    """一台 SN 的当前状态。状态机：pending→passed/failed→rework→station_done→packed"""
    __tablename__ = "units"
    id = Column(Integer, primary_key=True, index=True)
    sn = Column(String(64), unique=True, nullable=False, index=True)
    wo_id = Column(Integer, ForeignKey("wos.id"), nullable=False)
    current_station = Column(String(64))
    state = Column(String(32), default="pending", index=True)
    fail_code = Column(String(64))
    box_no = Column(String(64))
    created_at = Column(DateTime, default=datetime.utcnow)

    wo = relationship("WorkOrder", back_populates="sns")
    records = relationship("StationRecord", back_populates="unit", cascade="all, delete-orphan")


class StationRecord(Base):
    """过站记录：引用式关联 SN，不把字段塞进 units 表（借鉴 KTG source_doc_id）"""
    __tablename__ = "station_records"
    id = Column(Integer, primary_key=True, index=True)
    unit_id = Column(Integer, ForeignKey("units.id"), nullable=False, index=True)
    station = Column(String(64), nullable=False)
    result = Column(String(16), nullable=False)   # pass/fail/rework
    fail_code = Column(String(64))
    source_type = Column(String(32), default="station")  # 预留统一待检队列
    operator = Column(String(64))
    created_at = Column(DateTime, default=datetime.utcnow)

    unit = relationship("Unit", back_populates="records")


class Box(Base):
    __tablename__ = "boxes"
    id = Column(Integer, primary_key=True, index=True)
    box_no = Column(String(64), unique=True, nullable=False, index=True)
    wo_id = Column(Integer, ForeignKey("wos.id"), nullable=False)
    qty = Column(Integer, default=0)
    status = Column(String(32), default="open")  # open/closed
    created_at = Column(DateTime, default=datetime.utcnow)
    closed_at = Column(DateTime)
