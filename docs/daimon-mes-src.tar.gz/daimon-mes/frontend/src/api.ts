// API 客户端 · 戴盟 MES 生产管理平台
const TOKEN_KEY = 'mes_token'

export function getToken(): string {
  return localStorage.getItem(TOKEN_KEY) || ''
}
export function setToken(t: string) {
  localStorage.setItem(TOKEN_KEY, t)
}
export function clearToken() {
  localStorage.removeItem(TOKEN_KEY)
}

async function req<T = any>(path: string, data?: any, method?: string): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  const token = getToken()
  if (token) headers['Authorization'] = 'Bearer ' + token
  const res = await fetch(path, {
    method: method || (data !== undefined ? 'POST' : 'GET'),
    headers,
    body: data !== undefined ? JSON.stringify(data) : undefined,
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(body.detail || `请求失败 ${res.status}`)
  return body as T
}

export const api = {
  login: (username: string, password: string) => req('/api/login', { username, password }),
  products: () => req<any[]>('/api/products'),
  listWO: () => req<any[]>('/api/wos'),
  createWO: (d: any) => req('/api/wos', d),
  getWO: (id: number) => req(`/api/wos/${id}`),
  importSN: (woId: number, sns: string[]) => req(`/api/wos/${woId}/sns`, { wo_id: woId, sns }),
  station: (d: any) => req('/api/station', d),
  rework: (woId: number, sn: string) => req(`/api/wos/${woId}/sns/${encodeURIComponent(sn)}/rework`, {}),
  pack: (d: any) => req('/api/pack', d),
  querySN: (sn: string) => req(`/api/query/sn/${encodeURIComponent(sn)}`),
  queryWO: (id: number) => req(`/api/query/wo/${id}`),
  queryBox: (no: string) => req(`/api/query/box/${encodeURIComponent(no)}`),
}
