import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import App from './App.vue'
import Login from './views/Login.vue'
import WO from './views/WO.vue'
import Station from './views/Station.vue'
import Pack from './views/Pack.vue'
import Query from './views/Query.vue'
import { getToken } from './api'
import './style.css'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', component: Login },
    { path: '/wo', component: WO },
    { path: '/station', component: Station },
    { path: '/pack', component: Pack },
    { path: '/query', component: Query },
    { path: '/', redirect: '/wo' },
  ],
})

router.beforeEach((to, _from, next) => {
  if (to.path !== '/login' && !getToken()) next('/login')
  else next()
})

createApp(App).use(router).mount('#app')
