<template>
  <div class="grid g2">
    <div class="card">
      <h2>过站作业</h2>
      <p class="sub">手机手动输入 SN；扫码枪后续再加</p>
      <div class="field"><label>工单</label><select v-model="woId"><option value="">请选择</option><option v-for="w in wos" :key="w.id" :value="w.id">{{ w.wo_no }} · {{ w.product }}</option></select></div>
      <div class="field"><label>站点（本单序列，按顺序）</label>
        <div class="row">
          <button v-for="s in stations" :key="s" class="btn" :class="{ primary: station === s }" @click="station = s">{{ s }}</button>
        </div>
      </div>
      <div class="field"><label>SN</label><input v-model="sn" class="mono" placeholder="DAP93226AS00019D" /></div>
      <div class="field"><label>判定</label>
        <div class="row">
          <button class="btn" :class="{ primary: result === 'pass' }" @click="result = 'pass'">通过</button>
          <button class="btn" :class="{ primary: result === 'fail' }" @click="result = 'fail'">不良</button>
        </div>
      </div>
      <div v-if="result === 'fail'" class="field"><label>不良原因码</label><input v-model="failCode" placeholder="如：外观划伤" /></div>
      <div class="field"><label>操作人</label><input v-model="operator" placeholder="op01" /></div>
      <button class="btn primary" @click="submit" :disabled="!woId || !station || !sn">提交过站</button>
      <div v-if="msg" :class="['msg', ok ? 'ok' : 'err']" style="margin-top:16px">{{ msg }}</div>
    </div>

    <div class="card">
      <h2>本单进度</h2>
      <p class="sub">实时看已过站、不良、已装箱数</p>
      <div v-if="woId" class="grid g3" style="margin-bottom:18px">
        <div><label>总数</label><div style="font-size:32px;font-weight:800">{{ stat.total || 0 }}</div></div>
        <div><label>已过站</label><div style="font-size:32px;font-weight:800;color:var(--green)">{{ stat.station_done || 0 }}</div></div>
        <div><label>不良</label><div style="font-size:32px;font-weight:800;color:var(--red)">{{ stat.failed || 0 }}</div></div>
      </div>
      <div v-if="latest" class="msg ok">
        <b>{{ latest.sn }}</b> · {{ latest.station }} · <span :class="['tag', latest.result === 'pass' ? 'station_done' : 'failed']">{{ latest.result }}</span>
      </div>
      <p style="font-size:13px;color:var(--muted);line-height:1.8">
        状态机由服务端统一校验：不能跳站、重复提交自动幂等跳过、状态流转不散落在页面。
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { api } from '../api'

const wos = ref<any[]>([])
const woId = ref<number | ''>('')
const stations = ref<string[]>([])
const station = ref('')
const sn = ref('')
const result = ref<'pass' | 'fail'>('pass')
const failCode = ref('')
const operator = ref('op01')
const msg = ref(''); const ok = ref(true)
const stat = ref<any>({})
const latest = ref<any>(null)

onMounted(async () => { wos.value = await api.listWO() })
watch(woId, async (id) => {
  station.value = ''; stat.value = {}
  if (!id) { stations.value = []; return }
  const d = await api.getWO(Number(id))
  stations.value = d.wo.stations || []
  stat.value = await api.queryWO(Number(id))
})

async function submit() {
  try {
    const r = await api.station({
      sn: sn.value.trim(), station: station.value, result: result.value,
      fail_code: result.value === 'fail' ? failCode.value : undefined,
      operator: operator.value,
    })
    msg.value = r.msg || '过站成功'; ok.value = true
    latest.value = { sn: sn.value, station: station.value, result: result.value }
    sn.value = ''; failCode.value = ''
    stat.value = await api.queryWO(Number(woId.value))
  } catch (e: any) { msg.value = e.message; ok.value = false }
}
</script>
