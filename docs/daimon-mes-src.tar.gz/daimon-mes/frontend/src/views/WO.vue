<template>
  <div>
    <div class="grid g2">
      <div class="card">
        <h2>新建工单</h2>
        <p class="sub">建单时把站点序列和装箱配比定死</p>
        <div class="field"><label>工单号</label><input v-model="form.wo_no" placeholder="WO-20261119-001" /></div>
        <div class="field"><label>产品</label><select v-model="form.product"><option v-for="p in products" :key="p.code" :value="p.name">{{ p.name }}</option></select></div>
        <div class="row">
          <div class="field" style="flex:1"><label>批次</label><input v-model="form.batch" placeholder="第一批" /></div>
          <div class="field" style="flex:1"><label>计划数</label><input v-model.number="form.plan_qty" type="number" /></div>
        </div>
        <div class="field"><label>站点序列（逗号分隔，按过站顺序）</label><input v-model="stationsText" placeholder="压力测试,系统部署,出货检查" /></div>
        <div class="field"><label>装箱配比（每台箱装几台）</label><input v-model.number="form.pack_qty" type="number" /></div>
        <div class="field"><label>产出地点</label><select v-model="form.location"><option>戴盟公司</option><option>联想智造</option></select></div>
        <button class="btn primary" @click="create">建单</button>
      </div>

      <div class="card">
        <h2>导入 SN 清单</h2>
        <p class="sub">导入现成清单；重复 SN 自动跳过（幂等）</p>
        <div class="field"><label>选择工单</label><select v-model="importWO"><option value="">请选择</option><option v-for="w in wos" :key="w.id" :value="w.id">{{ w.wo_no }} · {{ w.product }}</option></select></div>
        <div class="field"><label>SN 清单（每行一个，或逗号分隔）</label><textarea v-model="snText" rows="8" placeholder="DAP93226AS00019D&#10;DAP93226AS000294"></textarea></div>
        <button class="btn primary" @click="importSNs" :disabled="!importWO">导入</button>
      </div>
    </div>

    <div v-if="msg" :class="['msg', msgOk ? 'ok' : 'err']">{{ msg }}</div>

    <div class="card">
      <h2>工单列表</h2>
      <div class="table-scroll">
      <table>
        <thead><tr><th>工单号</th><th>产品</th><th>批次</th><th>计划</th><th>站点序列</th><th>配比</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="w in wos" :key="w.id">
            <td class="mono">{{ w.wo_no }}</td><td>{{ w.product }}</td><td>{{ w.batch }}</td>
            <td>{{ w.plan_qty }}</td><td>{{ (w.stations || []).join(' → ') }}</td><td>{{ w.pack_qty }}</td>
            <td><span :class="['tag', w.status]">{{ w.status }}</span></td>
            <td><button class="btn" @click="viewWO(w.id)">查看 SN</button></td>
          </tr>
          <tr v-if="!wos.length"><td colspan="8" style="text-align:center;color:var(--muted)">暂无工单</td></tr>
        </tbody>
      </table>
      </div>
    </div>

    <div v-if="detail" class="card">
      <h2>{{ detail.wo.wo_no }} · SN 清单</h2>
      <div class="table-scroll">
      <table><thead><tr><th>SN</th><th>当前站</th><th>状态</th><th>不良码</th><th>箱号</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="u in detail.sns" :key="u.id">
            <td class="mono">{{ u.sn }}</td><td>{{ u.current_station || '—' }}</td>
            <td><span :class="['tag', u.state]">{{ u.state }}</span></td>
            <td>{{ u.fail_code || '—' }}</td><td class="mono">{{ u.box_no || '—' }}</td>
            <td><button v-if="u.state === 'failed'" class="btn" @click="rework(u)">返修回当前站</button></td>
          </tr>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { api } from '../api'

const products = ref<any[]>([])
const wos = ref<any[]>([])
const detail = ref<any>(null)
const msg = ref(''); const msgOk = ref(true)
const stationsText = ref('压力测试,系统部署,出货检查')
const form = ref({ wo_no: '', product: '', batch: '', plan_qty: 0, pack_qty: 1, location: '戴盟公司' })
const importWO = ref<number | ''>('')
const snText = ref('')

function notify(m: string, ok = true) { msg.value = m; msgOk.value = ok }

async function load() {
  products.value = await api.products()
  if (products.value.length && !form.value.product) form.value.product = products.value[0].name
  wos.value = await api.listWO()
}
onMounted(load)

async function create() {
  try {
    const stations = stationsText.value.split(/[,，]/).map(s => s.trim()).filter(Boolean)
    await api.createWO({ ...form.value, stations })
    notify('工单创建成功'); form.value.wo_no = ''; await load()
  } catch (e: any) { notify(e.message, false) }
}

async function importSNs() {
  try {
    const sns = snText.value.split(/[\r\n,，]/).map(s => s.trim()).filter(Boolean)
    const r = await api.importSN(Number(importWO.value), sns)
    notify(`导入 ${r.added} 条，跳过重复 ${r.skipped.length} 条`)
  } catch (e: any) { notify(e.message, false) }
}

async function viewWO(id: number) { detail.value = await api.getWO(id) }
async function rework(u: any) {
  try { await api.rework(detail.value.wo.id, u.sn); notify('已回到当前站重测'); detail.value = await api.getWO(detail.value.wo.id) }
  catch (e: any) { notify(e.message, false) }
}
</script>
