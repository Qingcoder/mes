<template>
  <div class="login-card">
    <h2>账号登录</h2>
    <p class="sub">单账号登录，防止误操作</p>
    <form @submit.prevent="submit">
      <div class="field">
        <label>用户名</label>
        <input v-model="username" autocomplete="off" placeholder="admin" />
      </div>
      <div class="field">
        <label>密码</label>
        <input v-model="password" type="password" autocomplete="new-password" inputmode="numeric" placeholder="请输入密码" />
      </div>
      <div v-if="msg" class="msg err">{{ msg }}</div>
      <button class="btn primary" type="submit" :disabled="loading">{{ loading ? '登录中…' : '登录' }}</button>
    </form>
    <p style="margin-top:16px;font-size:12px;color:var(--muted)">初始账号 admin / 123456 · 正式使用前请修改</p>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { api, setToken } from '../api'

const username = ref('admin')
const password = ref('')
const msg = ref('')
const loading = ref(false)
const router = useRouter()

async function submit() {
  loading.value = true; msg.value = ''
  try {
    const r = await api.login(username.value, password.value)
    if (!r.ok) { msg.value = r.msg || '登录失败'; return }
    setToken(r.token)
    router.push('/wo')
  } catch (e: any) { msg.value = e.message }
  finally { loading.value = false }
}
</script>
