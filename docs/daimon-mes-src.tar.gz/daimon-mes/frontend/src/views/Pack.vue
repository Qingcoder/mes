<template>
  <div class="grid g2">
    <div class="card">
      <h2>包装出库</h2>
      <p class="sub">所有 SN 必须通过最后一站才允许装箱</p>
      <div class="field"><label>箱号</label><input v-model="boxNo" class="mono" placeholder="BOX-001" /></div>
      <div class="field"><label>本箱 SN（每行一个）</label><textarea v-model="snText" rows="10" class="mono" placeholder="DAP93226AS00019D&#10;DAP93226AS000294"></textarea></div>
      <div class="field"><label>操作人</label><input v-model="operator" placeholder="op01" /></div>
      <button class="btn primary" @click="submit" :disabled="!boxNo || !snText.trim()">封箱出库</button>
      <div v-if="msg" :class="['msg', ok ? 'ok' : 'err']" style="margin-top:16px">{{ msg }}</div>
    </div>
    <div class="card">
      <h2>装箱规则</h2>
      <ul style="line-height:2;margin-left:20px;color:var(--gray)">
        <li>配比在建单时自定义（N 台/箱），不写死产品类型</li>
        <li>一箱只能装同一工单的 SN</li>
        <li>未通过全部站点的 SN 会被拒绝</li>
        <li>封箱后生成箱号，可在「数据查询」按箱号反查</li>
      </ul>
      <div class="msg ok" v-if="lastBox">
        已封箱：<b class="mono">{{ lastBox.box_no }}</b> · {{ lastBox.qty }} 台
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { api } from '../api'
const boxNo = ref(''); const snText = ref(''); const operator = ref('op01')
const msg = ref(''); const ok = ref(true); const lastBox = ref<any>(null)
async function submit() {
  try {
    const sns = snText.value.split(/[\r\n,，]/).map(s => s.trim()).filter(Boolean)
    const r = await api.pack({ box_no: boxNo.value.trim(), sns, operator: operator.value })
    lastBox.value = r; msg.value = `封箱成功：${r.box_no}（${r.qty} 台）`; ok.value = true
    boxNo.value = ''; snText.value = ''
  } catch (e: any) { msg.value = e.message; ok.value = false }
}
</script>
