<template>
  <div v-if="isLogin" class="login-page">
    <div class="login-left">
      <div class="hud-grid"></div>
      <div class="hud-corners"><i></i><i></i><i></i><i></i></div>

      <div class="hero">
        <div class="core">
          <div class="hud">
            <i class="ring r1"></i>
            <i class="ring r2"></i>
            <i class="ring r3"></i>
            <i class="ring r4"></i>
            <i class="ring r5"></i>
            <i class="ticks"></i>
            <i class="arc-red"></i>
            <i class="core-disc"></i>
            <i class="halo"></i>
          </div>
          <DaimonLogo class="core-logo" />
        </div>
        <h1>MES 生产管理平台</h1>
        <p>记录不再靠纸和群消息。<br>工单、过站、装箱、出库，一套系统跑完，每个 SN 都留痕。</p>
      </div>

      <div class="foot">戴盟（深圳）机器人科技有限公司 · V1.0</div>
    </div>
    <div class="login-right"><router-view /></div>
  </div>

  <div v-else class="app">
    <aside class="sidebar">
      <div class="brand">
        <span class="mark">D</span>
        <b>戴盟 MES</b>
        <small>生产管理平台 V1.0</small>
      </div>
      <nav class="nav">
        <router-link class="nav-item" to="/wo" active-class="active"><i class="ni">▤</i><span>工单维护</span></router-link>
        <router-link class="nav-item" to="/station" active-class="active"><i class="ni">▷</i><span>过站作业</span></router-link>
        <router-link class="nav-item" to="/pack" active-class="active"><i class="ni">▣</i><span>包装出库</span></router-link>
        <router-link class="nav-item" to="/query" active-class="active"><i class="ni">⌕</i><span>数据查询</span></router-link>
      </nav>
      <div class="side-foot">戴盟（深圳）机器人科技有限公司<br>数据存于本机 · 手机浏览器访问</div>
    </aside>
    <div class="main">
      <header class="topbar">
        <h1>{{ title }}</h1>
        <div class="sep"></div>
        <button class="btn" @click="logout">退出登录</button>
      </header>
      <main class="content"><router-view /></main>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { clearToken } from './api'
import DaimonLogo from './components/DaimonLogo.vue'

const route = useRoute()
const router = useRouter()
const isLogin = computed(() => route.path === '/login')
const titles: Record<string, string> = {
  '/wo': '工单维护', '/station': '过站作业', '/pack': '包装出库', '/query': '数据查询',
}
const title = computed(() => titles[route.path] || '戴盟 MES 生产管理平台')
function logout() { clearToken(); router.push('/login') }
</script>
