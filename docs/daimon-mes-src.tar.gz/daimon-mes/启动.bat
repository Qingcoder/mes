@echo off
chcp 65001 >nul
cd /d %~dp0
echo ==========================================
echo   戴盟 MES 生产管理平台 · 一键启动
echo ==========================================

where python >nul 2>nul || (echo [错误] 未找到 Python，请先安装 Python 3.11+ 并勾选 Add to PATH & pause & exit /b 1)
where npm >nul 2>nul || (echo [错误] 未找到 Node.js，请先安装 Node 18+ & pause & exit /b 1)

if not exist "backend\.venv\Scripts\python.exe" (
  echo [1/3] 首次运行：创建 Python 虚拟环境 ...
  python -m venv backend\.venv || (echo 创建虚拟环境失败 & pause & exit /b 1)
)
echo [2/3] 检查后端依赖 ...
backend\.venv\Scripts\python.exe -m pip install -q --disable-pip-version-check -r backend\requirements.txt

if not exist "frontend\node_modules" (
  echo [3/3] 首次运行：安装前端依赖（约 1-2 分钟）...
  pushd frontend
  call npm install
  popd
) else (
  echo [3/3] 前端依赖已就绪
)

echo.
echo 启动后端 :8007 与前端 :5173 ...
start "MES-BACKEND"  cmd /k "cd /d %~dp0backend  && .venv\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8007"
start "MES-FRONTEND" cmd /k "cd /d %~dp0frontend && npm run dev"

echo.
echo   电脑访问：http://127.0.0.1:5173/login
echo   手机访问：http://本机局域网IP:8007/login  （同 WiFi，扫码入口见 手机扫码入口.html）
echo.
pause
